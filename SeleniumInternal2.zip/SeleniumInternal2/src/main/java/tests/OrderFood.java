package tests;

import java.io.IOException;
import java.util.concurrent.TimeUnit;

import org.junit.Assert;
import org.openqa.selenium.By;
import org.openqa.selenium.JavascriptExecutor;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.support.ui.ExpectedCondition;
import org.openqa.selenium.support.ui.ExpectedConditions;
import org.openqa.selenium.support.ui.WebDriverWait;
import org.testng.annotations.Test;

import pages.BrandType;
import util.BaseTest;
import util.TestUtils;

public class OrderFood extends BaseTest {
	TestUtils util = new TestUtils();
	BrandType brand;

	@Test
	public void placeOrder() throws InterruptedException, IOException {
		driver = driverInit();
		brand = new BrandType(driver);
		brand.selectBrand();
		Thread.sleep(5000L);
		brand.acceptCookies();
		brand.addAddress();
		brand.clickOnSubmit();
		driver.manage().timeouts().implicitlyWait(15, TimeUnit.SECONDS);
		WebDriverWait wt = new WebDriverWait(driver, 60);
		wt.until(ExpectedConditions.invisibilityOf(brand.getShoppingCartWindow()));
		util.wiatForVisibilityOfElement(brand.getShoppingCartWindow());
		brand.selectFood(loadProperties("config.properties").getProperty("foodName")).click();
		util.wiatForClickableElement(brand.submitOrderButton());
		
		util.scrollIntoView(brand.submitOrderButton());
		brand.submitOrderButton().click();// driver.findElement(By.id("topup-modal--close")).click();
		util.wiatForVisibilityOfElement(brand.getShoppingCartWindow());

		Assert.assertTrue(brand.validateItemText(loadProperties("config.properties").getProperty("foodName")));
		Assert.assertTrue(brand.validateOrderMsg(loadProperties("config.properties").getProperty("orderMsg")));

	}
}
