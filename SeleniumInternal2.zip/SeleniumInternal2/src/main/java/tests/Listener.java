package tests;

import java.net.MalformedURLException;
import java.text.DateFormat;
import java.text.SimpleDateFormat;
import java.util.Date;

import javax.mail.MessagingException;

import org.apache.logging.log4j.LogManager;
import org.apache.logging.log4j.Logger;
import org.testng.ITestContext;
import org.testng.ITestListener;
import org.testng.ITestResult;

import util.BaseTest;
import util.EmailNotify;
import util.TestUtils;

public class Listener implements ITestListener {
	TestUtils util=new TestUtils();
	BaseTest base=new BaseTest();
	public static Logger log = LogManager.getLogger(Listener.class.getClass());
	String path=System.getProperty("user.dir");
	SimpleDateFormat dateFormat = new SimpleDateFormat("yyyy-MM-dd HH-mm-ss");
     Date date = new Date();
	public void onFinish(ITestResult Result) {
		System.out.println("test case execution is finished" + Result.getName());
		log.info("test case execution is finished ::"+Result.getName());
	}

	public void onStart(ITestResult Result) {
		System.out.println("test case execution statrted"+ Result.getName());
		log.info("test case execution is started ::"+Result.getName());
	}

	public void onTestFailure(ITestResult Result) {
		System.out.println("The name of the testcase failed is :" + Result.getName());
		log.info("test case execution is failed ::"+Result.getName());
		util.takeScreenShot(path+"\\Screenshots\\Failed\\"+Result.getName()+"-"+dateFormat.format(date)+".png");
		EmailNotify email=new EmailNotify();
		email.sendText("testingsample095@gmail.com","Testing@111",Result.getName());
			}

	public void onTestSkipped(ITestResult Result) {
		System.out.println("The name of the testcase Skipped is :" + Result.getName());
		log.info("test case execution is skipped ::"+Result.getName());
		util.takeScreenShot(path+"\\Screenshots\\Failed\\"+Result.getName()+"-"+dateFormat.format(date)+".png");
	}

	public void onTestSuccess(ITestResult Result) {
		System.out.println("The name of the testcase passed is :" + Result.getName());
		log.info("test case execution is success ::"+Result.getName());
		System.out.println(dateFormat.format(date));
		util.takeScreenShot(path+"\\Screenshots\\Passed\\"+Result.getName()+"-"+dateFormat.format(date)+".png");
		//EmailNotify email=new EmailNotify();
		//email.sendText("testingsample095@gmail.com","Testing@111");
		
	}

	@Override
	public void onTestStart(ITestResult Result) {
		// TODO Auto-generated method stub
		System.out.println("test case execution is fstarted" + Result.getName());
		log.info("test case execution is finished ::"+Result.getName());
	}

	@Override
	public void onTestFailedButWithinSuccessPercentage(ITestResult result) {
		// TODO Auto-generated method stub
		
	}

	@Override
	public void onStart(ITestContext context) {
		// TODO Auto-generated method stub
		
	}

	@Override
	public void onFinish(ITestContext context) {
		// TODO Auto-generated method stub
		EmailNotify email=new EmailNotify();
		try {
			email.attachFile(base.loadProperties("config.properties").getProperty("Email"),base.loadProperties("config.properties").getProperty("password"));
		} catch (MalformedURLException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
	}
}
