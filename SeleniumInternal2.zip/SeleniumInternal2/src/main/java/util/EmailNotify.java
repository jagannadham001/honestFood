package util;
import java.net.MalformedURLException;
import java.net.URL;
import java.util.Properties;
import javax.activation.DataHandler;
import javax.activation.DataSource;
import javax.activation.FileDataSource;
import javax.mail.BodyPart;
import javax.mail.Message;
import javax.mail.MessagingException;
import javax.mail.Multipart;
import javax.mail.PasswordAuthentication;
import javax.mail.Session;
import javax.mail.Transport;
import javax.mail.internet.InternetAddress;
import javax.mail.internet.MimeBodyPart;
import javax.mail.internet.MimeMessage;
import javax.mail.internet.MimeMultipart;

import org.apache.commons.mail.DefaultAuthenticator;
import org.apache.commons.mail.Email;
import org.apache.commons.mail.EmailAttachment;
import org.apache.commons.mail.EmailException;
import org.apache.commons.mail.MultiPartEmail;
import org.apache.commons.mail.SimpleEmail;
import org.testng.annotations.AfterSuite;

public class EmailNotify {
  String path=System.getProperty("user.dir");
 
 
public void sendText(String mailId,String passWord,String method) {
	 Email email = new SimpleEmail();
	 email.setHostName("smtp.googlemail.com");
	 email.setSmtpPort(587);
	 email.setStartTLSEnabled(true);
	 email.setAuthenticator(new DefaultAuthenticator(mailId, passWord));
	 email.setSSLOnConnect(true);
	 try {
		email.setFrom(mailId);
		 email.setSubject("Alerting mail for failed test method");
		 email.setMsg("Alertin mail for failed test methods ... :- "+method);
		 email.addTo(mailId);
		 email.send();
	} catch (EmailException e) {
		// TODO Auto-generated catch block
		e.printStackTrace();
	}

	 
 }
public void attachFile(String emailId,String passWord) throws MalformedURLException {
	EmailAttachment attachment = new EmailAttachment();
	attachment.setPath(path+"\\target\\surefire-reports\\emailable-report.html");
	 
	  attachment.setDisposition(EmailAttachment.ATTACHMENT);
	  attachment.setDescription("Reports");
	  attachment.setName("Reports");

	  // Create the email message
	  MultiPartEmail email = new MultiPartEmail();
	  email.setHostName("smtp.googlemail.com");
		 email.setStartTLSEnabled(true);
		 email.setSmtpPort(587);
		 email.setAuthenticator(new DefaultAuthenticator(emailId, passWord));
		 email.setSSLOnConnect(true);
	  try {
		email.addTo(emailId, "Jagan");
		email.setFrom(emailId, "Me");
		  email.setSubject("Email reports");
		  email.setMsg("Here is generated reports");
		  // add the attachment
		  email.attach(attachment);
		  // send the email
		  email.send();
	} catch (EmailException e) {
		// TODO Auto-generated catch block
		e.printStackTrace();
	}
	  
}
}

