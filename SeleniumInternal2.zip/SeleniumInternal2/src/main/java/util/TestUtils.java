package util;

import java.io.File;
import java.io.FileInputStream;
import java.io.FileNotFoundException;
import java.io.IOException;

import org.apache.commons.io.FileUtils;
import org.apache.poi.xssf.usermodel.XSSFCell;
import org.apache.poi.xssf.usermodel.XSSFRow;
import org.apache.poi.xssf.usermodel.XSSFSheet;
import org.apache.poi.xssf.usermodel.XSSFWorkbook;
import org.openqa.selenium.By;
import org.openqa.selenium.JavascriptExecutor;
import org.openqa.selenium.OutputType;
import org.openqa.selenium.TakesScreenshot;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.support.ui.ExpectedConditions;
import org.openqa.selenium.support.ui.Select;
import org.openqa.selenium.support.ui.WebDriverWait;
import org.testng.annotations.DataProvider;
import org.testng.annotations.Test;


public class TestUtils extends BaseTest {
	

	public void takeScreenShot(String filepath) {
		try {
			File tempfile, destinationfile;
			destinationfile = new File(filepath);
			TakesScreenshot screenShot = (TakesScreenshot) driver;
			tempfile = screenShot.getScreenshotAs(OutputType.FILE);

			FileUtils.copyFile(tempfile, destinationfile);
		} catch (IOException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
	}
	

	public void click(WebElement element) {
		element.click();

	}

	public void sendText(WebElement element, CharSequence text) {
		element.sendKeys(text);
	}

	public String getText(WebElement element) {
		String text = element.getText();
		return text;
	}

	public void selectDropdown(WebElement element, String value) {
		Select dropdown = new Select(element);
		dropdown.selectByVisibleText(value);
	}
	
	public void highlightElement(WebElement element) {
		JavascriptExecutor js = (JavascriptExecutor) driver;
        //Here i pass values based on css style. Yellow background color with solid red color border. 
      js.executeScript("arguments[0].setAttribute('style', 'background: yellow; border: 2px solid red;');", element);
	}
	
	public void wiatForVisibilityOfElement(WebElement element) {
		WebDriverWait wait=new WebDriverWait(driver, 15); 
    	wait.until(ExpectedConditions.visibilityOf(element));
	}
	
	public void wiatForClickableElement(WebElement element) {
		WebDriverWait wait=new WebDriverWait(driver, 15); 
    	wait.until(ExpectedConditions.elementToBeClickable(element));
	}
	
	public void scrollIntoView(WebElement element) {
		JavascriptExecutor js = (JavascriptExecutor) driver;
		js.executeScript("arguments[0].scrollIntoView(true);", driver.findElement(By.id("topup-modal--close")));
	}

}
