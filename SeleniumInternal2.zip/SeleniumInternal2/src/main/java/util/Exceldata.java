package util;

import java.io.FileInputStream;
import java.io.FileNotFoundException;
import java.io.IOException;

import org.apache.poi.ss.usermodel.Cell;
import org.apache.poi.ss.usermodel.Row;
import org.apache.poi.xssf.usermodel.XSSFSheet;
import org.apache.poi.xssf.usermodel.XSSFWorkbook;

public class Exceldata {
	public String[][] getCellData(String path, String sheetName) throws IOException {
		FileInputStream stream = new FileInputStream(path);
		XSSFWorkbook workbook = new XSSFWorkbook(stream);
		XSSFSheet sheet = workbook.getSheet(sheetName);
		System.out.println("sheet name="+sheet.getFirstRowNum());
		int rowcount = sheet.getLastRowNum()+1;
		System.out.println("sheet name="+rowcount);
		int cellcount = sheet.getRow(0).getLastCellNum();
		String data[][] = new String[rowcount][cellcount];
		for (int i = 0; i < rowcount; i++) {
			Row row = sheet.getRow(i);
			for (int j = 0; j < cellcount; j++) {
				Cell c = row.getCell(j);

				data[i][j] = c.toString();

			}
		}
		return data;
	}
}
