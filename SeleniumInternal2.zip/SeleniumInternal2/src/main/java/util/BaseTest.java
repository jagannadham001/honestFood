package util;

import java.io.FileInputStream;
import java.io.FileNotFoundException;
import java.io.IOException;
import java.util.Properties;
import java.util.concurrent.TimeUnit;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.chrome.ChromeDriver;
import org.openqa.selenium.firefox.FirefoxDriver;
import org.openqa.selenium.ie.InternetExplorerDriver;
import org.openqa.selenium.remote.DesiredCapabilities;
import org.testng.annotations.AfterSuite;

import io.github.bonigarcia.wdm.WebDriverManager;

public class BaseTest {

	public static WebDriver driver;
	static Properties prop = new Properties();
	static FileInputStream file;
	String path = System.getProperty("user.dir");

	public WebDriver driverInit() throws IOException {
		if (loadProperties("config.properties").getProperty("browser").equals("chrome")) {
			WebDriverManager.chromedriver().proxy(loadProperties("config.properties").getProperty("proxyValue"))
					.setup();
			driver = new ChromeDriver();
		}
		if (loadProperties("config.properties").getProperty("browser").equals("firefox")) {

			WebDriverManager.firefoxdriver().proxy(loadProperties("config.properties").getProperty("proxyValue"))
					.setup();
			driver = new FirefoxDriver();
		}
		if (loadProperties("config.properties").getProperty("browser").equals("IE")) {

			// WebDriverManager.iedriver().proxy(loadProperties("config.properties").getProperty("proxyValue")).setup();
			WebDriverManager.iedriver().setup();
			driver = new InternetExplorerDriver();
		}
		String Url = loadProperties("config.properties").getProperty("URL");
		driver.get(Url);
		driver.manage().window().maximize();
		driver.manage().timeouts().implicitlyWait(15, TimeUnit.SECONDS);
		

		return driver;

	}

	public Properties loadProperties(String fileName) {

		try {
			file = new FileInputStream(System.getProperty("user.dir") + "\\Resources\\Properties\\" + fileName + "");
		} catch (FileNotFoundException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
		try {
			prop.load(file);
		} catch (IOException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
		return prop;
	}
	@AfterSuite
	public void closeBrowser() {
		driver.close();
	}

}
