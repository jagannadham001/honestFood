package pages;

import java.util.List;

import org.openqa.selenium.By;
import org.openqa.selenium.JavascriptExecutor;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;

import util.BaseTest;

public class BrandType {
	 WebDriver driver=null;
     public BrandType(WebDriver driver) {
  	   this.driver=driver;
     }
 	
	BaseTest base=new BaseTest();
 	
 	By brandType=By.xpath(base.loadProperties("orderfood.loc").getProperty("brand.type"));
 	By quesadillas=By.xpath(base.loadProperties("orderfood.loc").getProperty("element.text"));
 	By address=By.id(base.loadProperties("orderfood.loc").getProperty("address"));
 	By cookiesOkButton=By.xpath(base.loadProperties("orderfood.loc").getProperty("button.cookies"));
 	By submitButton=By.xpath(base.loadProperties("orderfood.loc").getProperty("button.submit"));
 	By foodName=By.xpath(base.loadProperties("orderfood.loc").getProperty("foodname"));
 	By shoopingCart=By.xpath(base.loadProperties("orderfood.loc").getProperty("shopping.cart.basket"));
 	
 	By itemText=By.xpath(base.loadProperties("orderfood.loc").getProperty("itemText"));
 	By orderMsg=By.xpath(base.loadProperties("orderfood.loc").getProperty("orderSuccessMsg"));
 	By headerWareknorb=By.xpath(base.loadProperties("orderfood.loc").getProperty("wareknorb.header"));
 	By addOrdertoCart=By.id(base.loadProperties("orderfood.loc").getProperty("button.submit.order"));
 	public WebElement submitOrderButton() {
 		return driver.findElement(addOrdertoCart);
 	}
 	public WebElement getItemText() {
 		return driver.findElement(itemText);
 	}
 	public WebElement getShoppingCartWindow() {
 		return driver.findElement(shoopingCart);
 	}
 	
 	public boolean validateOrderMsg(String msg) {
 		return getOrderMsg().getText().contains(msg);
		
 	}
 	
 	public WebElement getOrderMsg() {
 		return driver.findElement(orderMsg);
 	}
 	public boolean validateItemText(String ItemName) {
 		return getItemText().getText().contains(ItemName);
 	}
 	public WebElement getHeaderWareknorb() {
 		return driver.findElement(headerWareknorb);
 	}
 	public WebElement getBrand() {
 		return driver.findElement(brandType);
 	}
 	public List<WebElement> getFoodName() {
 		List<WebElement> foodItem= driver.findElements(foodName);
 		return foodItem;
 	}
 	
 	public void selectFoodItem(String  food) {
 		//div[@class='product--info']//a/button[text()=' Avocado Crush Quesadilla ']
 		List<WebElement> foodItem= getFoodName();
 		for(int i=0;i<foodItem.size();i++) {
 			System.out.println("fooditem=="+foodItem.get(i).getText());
 			System.out.println("food=="+food);
 			if(foodItem.get(i).getText().contains(food)) {
 				System.out.println("inside iff");
 				//foodItem.get(i).click();
 				JavascriptExecutor executor = (JavascriptExecutor)driver;
 				executor.executeScript("arguments[0].click()", foodItem.get(i));
 				break;
 			}
 		}
 	}
 	
 	public WebElement getElement() {
 		return driver.findElement(quesadillas);
 	}
 	
 	public WebElement getAddress() {
 		return driver.findElement(address);
 	}
 	public WebElement getOkCookiesbutton() {
 		return driver.findElement(cookiesOkButton);
 	}
 	public WebElement getSubmitButton() {
 		return driver.findElement(submitButton);
 	}
 	
 	public void clickOnSubmit() {
 		getSubmitButton().click();
 	}
 	public void acceptCookies() {
 		getOkCookiesbutton().click();
 	}
 	
 	public void selectBrand() {
 		getBrand().click();
 	}
 	
 	public void addAddress() {
 		getAddress().sendKeys("Semperstraße 44, 1180 Wien, Austria");
 	}
 	
 	public WebElement selectFood(String name) {
 		//driver.findElement(By.xpath("//div[@class='product--info']//a/button[text()=' Avocado Crush Quesadilla ']"));
 		return driver.findElement(By.xpath("//div[@class='product--info']//a/button[text()=' "+name+" ']"));

 	}
	
		
	
 	
}
